'use client';

import { Check, X } from 'lucide-react';

interface ComparisonRow {
  aspect: string;
  slm: boolean | string;
  llm: boolean | string;
}

interface ComparisonTableProps {
  rows: ComparisonRow[];
  leftLabel: string;
  rightLabel: string;
}

export function ComparisonTable({ rows, leftLabel, rightLabel }: ComparisonTableProps) {
  return (
    <div className="overflow-x-auto">
      <table className="w-full">
        <thead>
          <tr className="border-b border-border/40">
            <th className="text-left py-4 px-4 font-semibold text-foreground">Aspect</th>
            <th className="text-center py-4 px-4 font-semibold text-accent">{leftLabel}</th>
            <th className="text-center py-4 px-4 font-semibold text-muted-foreground">{rightLabel}</th>
          </tr>
        </thead>
        <tbody>
          {rows.map((row, index) => (
            <tr key={index} className="border-b border-border/40 hover:bg-secondary/20 transition-colors">
              <td className="py-4 px-4 text-foreground">{row.aspect}</td>
              <td className="py-4 px-4 text-center">
                {typeof row.slm === 'boolean' ? (
                  row.slm ? (
                    <Check className="w-5 h-5 text-accent mx-auto" />
                  ) : (
                    <X className="w-5 h-5 text-muted-foreground/50 mx-auto" />
                  )
                ) : (
                  <span className="text-sm text-foreground">{row.slm}</span>
                )}
              </td>
              <td className="py-4 px-4 text-center">
                {typeof row.llm === 'boolean' ? (
                  row.llm ? (
                    <Check className="w-5 h-5 text-muted-foreground mx-auto" />
                  ) : (
                    <X className="w-5 h-5 text-muted-foreground/50 mx-auto" />
                  )
                ) : (
                  <span className="text-sm text-muted-foreground">{row.llm}</span>
                )}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
