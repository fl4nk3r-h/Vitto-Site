'use client';

import Link from 'next/link';
import { Button } from '@/components/ui/button';
import { GradientText } from '@/components/ui/gradient-text';
import { ArrowRight } from 'lucide-react';

export function CTA() {
  return (
    <section className="py-20 md:py-32 border-t border-border/40">
      <div className="container px-4">
        <div className="fade-in-up max-w-3xl mx-auto text-center">
          <h2 className="text-3xl md:text-5xl font-bold text-foreground mb-6">
            Ready to build <GradientText>AI-native</GradientText> banking?
          </h2>
          <p className="text-lg text-muted-foreground mb-8">
            Start in minutes. Comply in seconds. Scale without limits.
          </p>

          <Link href="/signup">
            <Button size="lg" className="bg-accent text-accent-foreground hover:bg-accent/90 group">
              Start Your Free Trial
              <ArrowRight className="ml-2 w-4 h-4 group-hover:translate-x-1 transition-transform" />
            </Button>
          </Link>
        </div>
      </div>
    </section>
  );
}
