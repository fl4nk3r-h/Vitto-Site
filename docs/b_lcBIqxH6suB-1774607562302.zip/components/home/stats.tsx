'use client';

import { STATS } from '@/lib/constants/testimonials';
import { useScrollAnimation } from '@/lib/hooks/useScrollAnimation';

export function Stats() {
  const { ref, isVisible } = useScrollAnimation();

  return (
    <section ref={ref} className="py-20 md:py-32 border-t border-border/40 bg-primary text-primary-foreground">
      <div className="container px-4">
        <h2 className="text-3xl md:text-4xl font-bold mb-16 text-center">
          Built for Enterprise Scale
        </h2>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          {STATS.map((stat, index) => (
            <div
              key={index}
              className={`text-center transition-all duration-500 ${isVisible ? 'fade-in-up opacity-100' : 'opacity-0'}`}
              style={isVisible ? { transitionDelay: `${index * 0.1}s` } : {}}
            >
              <div className="text-4xl md:text-5xl font-bold mb-2">
                {stat.number}
              </div>
              <div className="text-lg font-semibold mb-2">
                {stat.label}
              </div>
              <p className="text-sm text-primary-foreground/70">
                {stat.description}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
