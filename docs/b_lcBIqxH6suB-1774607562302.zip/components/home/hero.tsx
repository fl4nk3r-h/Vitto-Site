'use client';

import Link from 'next/link';
import { Button } from '@/components/ui/button';
import { GradientText } from '@/components/ui/gradient-text';
import { ArrowRight } from 'lucide-react';

export function Hero() {
  return (
    <section className="relative py-20 md:py-32 overflow-hidden">
      <div className="container px-4">
        <div className="fade-in-up max-w-3xl">
          <h1 className="text-4xl md:text-6xl font-bold text-foreground mb-6 leading-tight text-balance">
            AI-First <GradientText>Infrastructure</GradientText> for Banking
          </h1>
          <p className="text-lg md:text-xl text-muted-foreground mb-8 max-w-2xl text-balance">
            Build, deploy, and scale banking AI with domain-trained models. Infrastructure designed for compliance, security, and speed.
          </p>

          <div className="flex flex-col sm:flex-row gap-4">
            <Link href="/signup">
              <Button size="lg" className="bg-accent text-accent-foreground hover:bg-accent/90 group">
                Get Started
                <ArrowRight className="ml-2 w-4 h-4 group-hover:translate-x-1 transition-transform" />
              </Button>
            </Link>
            <Link href="/platform">
              <Button size="lg" variant="outline">
                Learn More
              </Button>
            </Link>
          </div>
        </div>

        {/* Decorative gradient background */}
        <div className="absolute top-0 right-0 w-96 h-96 bg-accent/10 rounded-full blur-3xl -z-10" />
      </div>
    </section>
  );
}
