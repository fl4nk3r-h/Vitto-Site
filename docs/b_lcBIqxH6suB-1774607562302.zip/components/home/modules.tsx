'use client';

import { GlowCard } from '@/components/ui/glow-card';
import { AI_FIRST_MODULES } from '@/lib/constants/modules';
import * as Icons from 'lucide-react';

export function Modules() {
  return (
    <section className="py-20 md:py-32 border-t border-border/40">
      <div className="container px-4">
        <div className="max-w-2xl mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">
            Six Core Modules
          </h2>
          <p className="text-lg text-muted-foreground">
            Each designed to solve a specific layer of banking AI infrastructure.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {AI_FIRST_MODULES.map((module, index) => {
            const IconComponent = Icons[module.icon as keyof typeof Icons] || Icons.Zap;
            return (
              <GlowCard key={module.id} delay={index * 0.05}>
                <IconComponent className="w-8 h-8 text-accent mb-3" />
                <h3 className="text-lg font-semibold text-foreground mb-2">
                  {module.title}
                </h3>
                <p className="text-sm text-muted-foreground mb-4">
                  {module.description}
                </p>
                <p className="text-xs text-accent">
                  {module.details}
                </p>
              </GlowCard>
            );
          })}
        </div>
      </div>
    </section>
  );
}
