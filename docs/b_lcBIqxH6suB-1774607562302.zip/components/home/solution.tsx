'use client';

import { CheckCircle2 } from 'lucide-react';

const SOLUTIONS = [
  {
    title: 'Domain-Trained SLM Core',
    description: 'Small language models pre-trained on 10+ years of banking data. Understand regulations naturally.'
  },
  {
    title: 'Compliance Built In',
    description: 'Audit trails, data governance, and regulatory controls from day one. Not an afterthought.'
  },
  {
    title: '29+ Operational Modules',
    description: 'Data processing, model management, compliance, integrations, and observability. Plug and play.'
  },
  {
    title: '15-Minute Integration',
    description: 'Pre-built connectors for core banking, CRM, and data warehouse systems. Go live in hours.'
  }
];

export function Solution() {
  return (
    <section className="py-20 md:py-32 border-t border-border/40 bg-secondary/30">
      <div className="container px-4">
        <div className="max-w-2xl mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">
            The Vitto Difference
          </h2>
          <p className="text-lg text-muted-foreground">
            AI-first infrastructure designed from the ground up for banking. Not a retrofit. Built for compliance, speed, and scale.
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-8">
          {SOLUTIONS.map((solution, index) => (
            <div
              key={index}
              className="fade-in-up flex gap-4"
              style={{ transitionDelay: `${index * 0.1}s` }}
            >
              <CheckCircle2 className="w-6 h-6 text-accent flex-shrink-0 mt-1" />
              <div>
                <h3 className="text-lg font-semibold text-foreground mb-2">
                  {solution.title}
                </h3>
                <p className="text-muted-foreground">
                  {solution.description}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
