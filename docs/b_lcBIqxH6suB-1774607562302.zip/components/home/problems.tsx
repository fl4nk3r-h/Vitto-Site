'use client';

import { GlowCard } from '@/components/ui/glow-card';
import { AlertCircle, Clock, Shield, Zap } from 'lucide-react';

const PROBLEMS = [
  {
    icon: Clock,
    title: 'Traditional ML Infrastructure is Slow',
    description: 'Weeks to months from concept to production. Banking timelines cannot wait.'
  },
  {
    icon: Shield,
    title: 'Compliance is Bolted On, Not Built In',
    description: 'Audit trails, regulatory controls, and data governance come after deployment. Risks multiply.'
  },
  {
    icon: Zap,
    title: 'Generic Models Miss Banking Context',
    description: 'Large language models don\'t understand BFSI workflows, regulations, or operational nuances.'
  },
  {
    icon: AlertCircle,
    title: 'Integration Chaos Across Systems',
    description: 'Core banking, CRM, data warehouse—every connection requires months of middleware work.'
  }
];

export function Problems() {
  return (
    <section className="py-20 md:py-32 border-t border-border/40">
      <div className="container px-4">
        <div className="max-w-2xl mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">
            The Problem with Retrofit AI
          </h2>
          <p className="text-lg text-muted-foreground">
            Most banking AI implementations are bolted onto existing infrastructure. It&apos;s slow, fragile, and non-compliant.
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-6">
          {PROBLEMS.map((problem, index) => (
            <GlowCard key={index} delay={index * 0.1}>
              <problem.icon className="w-6 h-6 text-accent mb-3" />
              <h3 className="text-lg font-semibold text-foreground mb-2">
                {problem.title}
              </h3>
              <p className="text-sm text-muted-foreground">
                {problem.description}
              </p>
            </GlowCard>
          ))}
        </div>
      </div>
    </section>
  );
}
