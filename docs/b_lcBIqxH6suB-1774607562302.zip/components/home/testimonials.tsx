'use client';

import { GlowCard } from '@/components/ui/glow-card';
import { TESTIMONIALS } from '@/lib/constants/testimonials';
import { Star } from 'lucide-react';

export function Testimonials() {
  return (
    <section className="py-20 md:py-32 border-t border-border/40 bg-secondary/30">
      <div className="container px-4">
        <div className="max-w-2xl mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">
            Trusted by India&apos;s Leading Banks
          </h2>
          <p className="text-lg text-muted-foreground">
            See how banking institutions are accelerating their AI roadmap with Vitto.
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-6">
          {TESTIMONIALS.map((testimonial, index) => (
            <GlowCard key={testimonial.id} delay={index * 0.1}>
              <div className="flex gap-1 mb-4">
                {Array.from({ length: 5 }).map((_, i) => (
                  <Star key={i} className="w-4 h-4 fill-accent text-accent" />
                ))}
              </div>
              <p className="text-muted-foreground mb-4 text-sm leading-relaxed">
                &ldquo;{testimonial.quote}&rdquo;
              </p>
              <div>
                <p className="font-semibold text-foreground text-sm">
                  {testimonial.author}
                </p>
                <p className="text-xs text-muted-foreground">
                  {testimonial.role} at {testimonial.company}
                </p>
              </div>
            </GlowCard>
          ))}
        </div>
      </div>
    </section>
  );
}
