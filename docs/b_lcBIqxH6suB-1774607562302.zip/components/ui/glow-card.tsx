'use client';

import React from 'react';

interface GlowCardProps {
  children: React.ReactNode;
  className?: string;
  delay?: number;
  icon?: React.ReactNode;
}

export function GlowCard({ children, className = '', delay = 0, icon }: GlowCardProps) {
  const style = delay ? { animationDelay: `${delay * 0.1}s` } : {};
  
  return (
    <div
      style={style}
      className={`fade-in-up relative rounded-lg border border-border/40 bg-card p-6 backdrop-blur-sm transition-all duration-300 hover:shadow-lg hover:shadow-accent/20 ${className}`}
    >
      {icon && <div className="mb-4 text-accent">{icon}</div>}
      {children}
    </div>
  );
}
