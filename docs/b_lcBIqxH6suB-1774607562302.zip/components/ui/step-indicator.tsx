'use client';

import React from 'react';

interface StepIndicatorProps {
  currentStep: number;
  totalSteps: number;
  labels?: string[];
}

export function StepIndicator({ currentStep, totalSteps, labels = [] }: StepIndicatorProps) {
  return (
    <div className="flex items-center justify-between">
      {Array.from({ length: totalSteps }).map((_, index) => {
        const stepNumber = index + 1;
        const isActive = stepNumber === currentStep;
        const isCompleted = stepNumber < currentStep;

        return (
          <div key={index} className="flex flex-1 items-center">
            <div
              className={`flex h-10 w-10 items-center justify-center rounded-full font-semibold transition-all duration-300 ${
                isActive
                  ? 'bg-accent text-accent-foreground shadow-lg shadow-accent/40'
                  : isCompleted
                    ? 'bg-accent/20 text-accent'
                    : 'bg-border text-muted-foreground'
              }`}
            >
              {stepNumber}
            </div>

            {index < totalSteps - 1 && (
              <div
                className={`h-1 flex-1 mx-2 transition-all duration-300 ${
                  isCompleted ? 'bg-accent' : 'bg-border'
                }`}
              />
            )}
          </div>
        );
      })}

      {labels.length > 0 && (
        <div className="mt-4 flex justify-between gap-2">
          {labels.map((label, index) => (
            <div key={index} className="flex-1 text-center text-sm text-muted-foreground">
              {label}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
