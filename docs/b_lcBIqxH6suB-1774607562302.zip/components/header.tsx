'use client';

import Link from 'next/link';
import { Menu, X } from 'lucide-react';
import { useState } from 'react';

export function Header() {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <header className="fixed top-0 left-0 right-0 z-50 h-16 border-b" style={{
      backgroundColor: 'rgba(7, 7, 26, 0.90)',
      backdropFilter: 'blur(20px)',
      borderBottomColor: 'var(--border-dim)'
    }}>
      <div className="container-vitto h-full flex items-center justify-between">
        {/* Logo */}
        <Link href="/" className="flex items-center gap-2" style={{ textDecoration: 'none' }}>
          <span style={{
            fontFamily: 'Inter, sans-serif',
            fontSize: '18px',
            fontWeight: 800,
            color: 'white',
            letterSpacing: '0.02em'
          }}>
            VITTO
          </span>
          <span style={{
            width: '8px',
            height: '8px',
            backgroundColor: 'var(--red)',
            borderRadius: '50%',
            animation: 'pulse-dot 2s infinite',
            display: 'inline-block'
          }} />
        </Link>

        {/* Desktop Navigation */}
        <nav className="hidden lg:flex items-center gap-8">
          {['Platform', 'Automation', 'Agentic AI', 'Collections', 'API', 'About'].map((item) => (
            <Link key={item} href={`/${item.toLowerCase().replace(' ', '-')}`} style={{
              fontSize: '14px',
              color: 'var(--text-secondary)',
              textDecoration: 'none',
              transition: 'color 200ms ease',
              display: 'block'
            }} className="nav-link">
              {item}
            </Link>
          ))}
        </nav>

        {/* Desktop CTA Button */}
        <button className="hidden lg:block btn-primary" style={{ padding: '8px 20px', fontSize: '14px' }}>
          Book a Demo
        </button>

        {/* Mobile Menu Button */}
        <button
          className="lg:hidden"
          onClick={() => setIsOpen(!isOpen)}
          style={{ background: 'none', border: 'none', cursor: 'pointer', color: 'var(--text-primary)' }}
          aria-label="Toggle menu"
        >
          {isOpen ? <X size={24} /> : <Menu size={24} />}
        </button>

        {/* Mobile Navigation */}
        {isOpen && (
          <nav className="absolute top-16 left-0 right-0 flex flex-col gap-4 p-6 lg:hidden" style={{
            backgroundColor: 'var(--bg-base)',
            borderBottomColor: 'var(--border-dim)',
            borderBottom: '1px solid var(--border-dim)'
          }}>
            {['Platform', 'Automation', 'Agentic AI', 'Collections', 'API', 'About'].map((item) => (
              <Link key={item} href={`/${item.toLowerCase().replace(' ', '-')}`} style={{
                color: 'var(--text-secondary)',
                textDecoration: 'none',
                fontSize: '14px'
              }} onClick={() => setIsOpen(false)}>
                {item}
              </Link>
            ))}
            <button className="btn-primary w-full mt-4">Book a Demo</button>
          </nav>
        )}
      </div>

      <style>{`
        .nav-link:hover {
          color: var(--text-primary);
        }
      `}</style>
    </header>
  );
}
