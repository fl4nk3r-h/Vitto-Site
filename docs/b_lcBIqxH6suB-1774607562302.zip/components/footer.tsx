'use client';

import Link from 'next/link';
import { Linkedin, Twitter } from 'lucide-react';

export function Footer() {
  return (
    <footer style={{
      background: '#04040F',
      borderTop: '1px solid var(--border-dim)',
      paddingTop: '96px',
      paddingBottom: '48px'
    }}>
      <div className="container-vitto px-4 md:px-0">
        {/* Top Section - 4 Column Grid */}
        <div style={{
          display: 'grid',
          gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))',
          gap: '48px',
          marginBottom: '48px'
        }}>
          {/* Col 1 - Brand */}
          <div>
            <div style={{
              fontFamily: 'Inter, sans-serif',
              fontSize: '16px',
              fontWeight: 800,
              marginBottom: '16px',
              color: 'white'
            }}>
              VITTO●
            </div>
            <p style={{
              color: 'var(--text-muted)',
              fontSize: '13px',
              lineHeight: '1.6',
              marginBottom: '20px'
            }}>
              AI-Native Digital Credit Infrastructure
            </p>
            
            {/* Newsletter */}
            <div>
              <p style={{
                color: 'var(--text-muted)',
                fontSize: '12px',
                marginBottom: '12px'
              }}>
                Stay updated on AI in BFSI
              </p>
              <div style={{
                display: 'flex',
                gap: '8px'
              }}>
                <input
                  type="email"
                  placeholder="your@email.com"
                  style={{
                    flex: 1,
                    background: 'var(--bg-surface)',
                    border: '1px solid var(--border-mid)',
                    borderRadius: '6px',
                    color: 'var(--text-primary)',
                    padding: '10px 16px',
                    fontSize: '13px',
                    fontFamily: 'Inter, sans-serif'
                  }}
                />
                <button className="btn-primary" style={{ padding: '10px 16px' }}>
                  Subscribe
                </button>
              </div>
            </div>
          </div>

          {/* Col 2 - Platform */}
          <div>
            <h4 style={{
              color: 'var(--text-primary)',
              fontSize: '13px',
              fontWeight: 600,
              marginBottom: '16px',
              textTransform: 'uppercase',
              fontFamily: 'JetBrains Mono, monospace'
            }}>
              Platform
            </h4>
            <ul style={{ listStyle: 'none', padding: 0, margin: 0 }}>
              {['Homepage', 'AI Platform', 'Automation', 'Collections', 'Agentic AI', 'API'].map((item) => (
                <li key={item} style={{ marginBottom: '12px' }}>
                  <Link href="#" style={{
                    color: 'var(--text-muted)',
                    textDecoration: 'none',
                    fontSize: '13px',
                    transition: 'color 200ms'
                  }} className="footer-link">
                    {item}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Col 3 - Company */}
          <div>
            <h4 style={{
              color: 'var(--text-primary)',
              fontSize: '13px',
              fontWeight: 600,
              marginBottom: '16px',
              textTransform: 'uppercase',
              fontFamily: 'JetBrains Mono, monospace'
            }}>
              Company
            </h4>
            <ul style={{ listStyle: 'none', padding: 0, margin: 0 }}>
              {['About', 'Why AI-Native', 'Careers', 'Blog'].map((item) => (
                <li key={item} style={{ marginBottom: '12px' }}>
                  <Link href="#" style={{
                    color: 'var(--text-muted)',
                    textDecoration: 'none',
                    fontSize: '13px',
                    transition: 'color 200ms'
                  }} className="footer-link">
                    {item}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Col 4 - Connect */}
          <div>
            <h4 style={{
              color: 'var(--text-primary)',
              fontSize: '13px',
              fontWeight: 600,
              marginBottom: '16px',
              textTransform: 'uppercase',
              fontFamily: 'JetBrains Mono, monospace'
            }}>
              Connect
            </h4>
            <div style={{
              display: 'flex',
              gap: '8px',
              marginBottom: '16px'
            }}>
              <a href="#" style={{
                width: '28px',
                height: '28px',
                background: 'var(--bg-elevated)',
                border: 'none',
                borderRadius: '6px',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                cursor: 'pointer',
                color: 'var(--text-muted)',
                transition: 'color 200ms'
              }} className="social-icon">
                <Linkedin size={16} />
              </a>
              <a href="#" style={{
                width: '28px',
                height: '28px',
                background: 'var(--bg-elevated)',
                border: 'none',
                borderRadius: '6px',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                cursor: 'pointer',
                color: 'var(--text-muted)',
                transition: 'color 200ms'
              }} className="social-icon">
                <Twitter size={16} />
              </a>
            </div>
            <p style={{
              color: 'var(--text-muted)',
              fontSize: '13px',
              marginBottom: '8px'
            }}>
              hello@vitto.ai
            </p>
            <p style={{
              color: 'var(--text-muted)',
              fontSize: '13px'
            }}>
              Mumbai, India
            </p>
          </div>
        </div>

        {/* Bottom Row */}
        <div style={{
          borderTop: '1px solid var(--border-dim)',
          paddingTop: '20px',
          display: 'flex',
          flexDirection: 'row',
          justifyContent: 'space-between',
          alignItems: 'center',
          fontSize: '12px',
          color: 'var(--text-muted)',
          gap: '16px'
        }}>
          <p>© 2025 Vitto Technologies Pvt. Ltd.</p>
          <div style={{ display: 'flex', gap: '16px' }}>
            <Link href="#" style={{ color: 'var(--text-muted)', textDecoration: 'none' }}>
              Privacy Policy
            </Link>
            <span>·</span>
            <Link href="#" style={{ color: 'var(--text-muted)', textDecoration: 'none' }}>
              Terms of Service
            </Link>
          </div>
        </div>
      </div>

      <style>{`
        .footer-link:hover {
          color: var(--text-primary);
        }
        .social-icon:hover {
          color: var(--text-primary);
          background: var(--bg-card);
        }
      `}</style>
    </footer>
  );
}
