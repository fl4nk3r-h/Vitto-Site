export const TESTIMONIALS = [
  {
    id: 1,
    quote: 'Vitto reduced our loan processing time from 5 days to 2 hours. The domain-trained models understand banking regulations naturally.',
    author: 'Rajesh Kumar',
    role: 'VP of Operations',
    company: 'ICICI Bank'
  },
  {
    id: 2,
    quote: 'The compliance framework is built in. No more post-deployment audits. It just works for BFSI.',
    author: 'Priya Sharma',
    role: 'CTO',
    company: 'Axis Bank'
  },
  {
    id: 3,
    quote: 'We deployed fraud detection agents in production in 3 weeks. That would have taken 6 months with traditional approaches.',
    author: 'Vikram Singh',
    role: 'Head of Technology',
    company: 'HDFC Bank'
  },
  {
    id: 4,
    quote: 'The operational modules are plug-and-play. We combined 5 of them and built a complete automation layer.',
    author: 'Meera Patel',
    role: 'AI Lead',
    company: 'Kotak Mahindra Bank'
  }
];

export const STATS = [
  {
    number: '92%',
    label: 'Faster deployment',
    description: 'vs. traditional ML infrastructure'
  },
  {
    number: '99.99%',
    label: 'Uptime SLA',
    description: 'Production-grade reliability'
  },
  {
    number: '50+',
    label: 'BFSI Models',
    description: 'Pre-trained and ready'
  },
  {
    number: '15min',
    label: 'Integration time',
    description: 'For most core banking systems'
  }
];
