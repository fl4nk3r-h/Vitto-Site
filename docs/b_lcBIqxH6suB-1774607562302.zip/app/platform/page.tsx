import { Header } from '@/components/header';
import { Footer } from '@/components/footer';
import { GradientText } from '@/components/ui/gradient-text';
import { GlowCard } from '@/components/ui/glow-card';
import { ComparisonTable } from '@/components/comparison-table';
import { AI_FIRST_MODULES } from '@/lib/constants/modules';
import * as Icons from 'lucide-react';
import Link from 'next/link';
import { Button } from '@/components/ui/button';

const comparisonRows = [
  {
    aspect: 'Training Data',
    slm: 'BFSI-specific (10+ years)',
    llm: 'General internet data'
  },
  {
    aspect: 'Latency',
    slm: '< 200ms',
    llm: '500ms - 2s'
  },
  {
    aspect: 'Cost per Request',
    slm: '$0.0001',
    llm: '$0.01 - $0.10'
  },
  {
    aspect: 'Compliance Built-In',
    slm: true,
    llm: false
  },
  {
    aspect: 'Data Residency',
    slm: true,
    llm: false
  },
  {
    aspect: 'Audit Trails',
    slm: true,
    llm: false
  }
];

export default function PlatformPage() {
  return (
    <main className="min-h-screen">
      <Header />

      {/* Hero */}
      <section className="py-20 md:py-32 border-b border-border/40">
        <div className="container px-4">
          <div className="max-w-3xl">
            <h1 className="text-4xl md:text-5xl font-bold text-foreground mb-6">
              The <GradientText>AI-First</GradientText> Platform for Banking
            </h1>
            <p className="text-lg text-muted-foreground mb-8">
              Six core modules, each designed to solve a critical layer of banking AI infrastructure. Domain-trained, compliance-built, production-ready.
            </p>
          </div>
        </div>
      </section>

      {/* Modules Grid */}
      <section className="py-20 md:py-32 border-b border-border/40">
        <div className="container px-4">
          <h2 className="text-3xl font-bold text-foreground mb-12">
            Six Core Modules
          </h2>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {AI_FIRST_MODULES.map((module) => {
              const IconComponent = Icons[module.icon as keyof typeof Icons] || Icons.Zap;
              return (
                <GlowCard key={module.id}>
                  <IconComponent className="w-8 h-8 text-accent mb-4" />
                  <h3 className="text-lg font-semibold text-foreground mb-2">
                    {module.title}
                  </h3>
                  <p className="text-sm text-muted-foreground mb-4">
                    {module.description}
                  </p>
                  <div className="pt-4 border-t border-border/40">
                    <p className="text-xs text-accent">
                      {module.details}
                    </p>
                  </div>
                </GlowCard>
              );
            })}
          </div>
        </div>
      </section>

      {/* SLM vs LLM Comparison */}
      <section className="py-20 md:py-32 border-b border-border/40 bg-secondary/30">
        <div className="container px-4">
          <div className="max-w-3xl mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">
              Domain-Trained SLM vs Generic LLM
            </h2>
            <p className="text-lg text-muted-foreground">
              Why small language models trained on BFSI data outperform generic large models for banking.
            </p>
          </div>

          <div className="border border-border/40 rounded-lg p-6 overflow-hidden">
            <ComparisonTable
              rows={comparisonRows}
              leftLabel="Domain-Trained SLM"
              rightLabel="Generic LLM"
            />
          </div>
        </div>
      </section>

      {/* Key Benefits */}
      <section className="py-20 md:py-32">
        <div className="container px-4">
          <h2 className="text-3xl font-bold text-foreground mb-12">
            Why Choose Vitto
          </h2>

          <div className="grid md:grid-cols-3 gap-8">
            {[
              {
                title: 'Production-Ready',
                description: 'No training. Deploy your first model in hours, not months.'
              },
              {
                title: 'Regulatory Compliant',
                description: 'Audit trails, data governance, and compliance reporting built-in from day one.'
              },
              {
                title: 'Banking-Focused',
                description: 'Models trained on BFSI workflows, regulations, and operational patterns.'
              },
              {
                title: '29+ Operational Modules',
                description: 'Data pipelines, model management, monitoring, compliance, and integration layers.'
              },
              {
                title: '99.99% Uptime SLA',
                description: 'Enterprise-grade reliability with automatic scaling and failover.'
              },
              {
                title: '15-Min Integration',
                description: 'Pre-built connectors for core banking, CRM, and data warehouse systems.'
              }
            ].map((benefit, index) => (
              <GlowCard key={index} delay={index * 0.1}>
                <h3 className="text-lg font-semibold text-foreground mb-2">
                  {benefit.title}
                </h3>
                <p className="text-sm text-muted-foreground">
                  {benefit.description}
                </p>
              </GlowCard>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-20 md:py-32 border-t border-border/40 bg-primary text-primary-foreground">
        <div className="container px-4 text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-6">
            Ready to go AI-native?
          </h2>
          <p className="text-lg mb-8 opacity-90">
            Explore the platform and see how it transforms your banking AI.
          </p>
          <Link href="/signup">
            <Button size="lg" className="bg-accent text-accent-foreground hover:bg-accent/90">
              Start Free Trial
            </Button>
          </Link>
        </div>
      </section>

      <Footer />
    </main>
  );
}
