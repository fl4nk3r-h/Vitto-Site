import { Header } from '@/components/header';
import { Footer } from '@/components/footer';
import { HeroNew } from '@/components/home/hero-new';

export default function Home() {
  return (
    <div style={{ backgroundColor: 'var(--bg-base)', color: 'var(--text-primary)' }}>
      <Header />
      <main className="pt-16">
        <HeroNew />
      </main>
      <Footer />
    </div>
  );
}
