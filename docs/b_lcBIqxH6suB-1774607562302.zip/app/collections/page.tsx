import { Header } from '@/components/header';
import { Footer } from '@/components/footer';
import { GradientText } from '@/components/ui/gradient-text';
import { GlowCard } from '@/components/ui/glow-card';
import Link from 'next/link';
import { Button } from '@/components/ui/button';
import { CheckCircle2, TrendingUp } from 'lucide-react';

const COLLECTIONS = [
  {
    title: 'Commercial Banking',
    description: 'Loan origination, credit decisions, and relationship management for large enterprises.',
    modules: [
      'Loan Processing Agent',
      'Risk Assessment Model',
      'Document Classification',
      'Compliance Validator',
      'Fraud Detection'
    ],
    impact: {
      processing: '85% faster',
      accuracy: '94% accuracy',
      cost: '70% reduction'
    }
  },
  {
    title: 'Retail Banking',
    description: 'Customer service, product recommendations, and financial advice automation.',
    modules: [
      'Customer Service Agent',
      'Product Recommendation Engine',
      'Account Analyzer',
      'Dispute Resolution',
      'Know-Your-Customer (KYC) Agent'
    ],
    impact: {
      processing: '24/7 availability',
      accuracy: '96% satisfaction',
      cost: '60% reduction'
    }
  },
  {
    title: 'Risk & Compliance',
    description: 'AML screening, regulatory reporting, and audit trail management.',
    modules: [
      'AML Screening Agent',
      'Regulatory Reporting',
      'Audit Logging System',
      'Policy Validation',
      'Compliance Monitoring'
    ],
    impact: {
      processing: '99.9% detection',
      accuracy: '100% audit coverage',
      cost: '50% reduction'
    }
  },
  {
    title: 'Collections & Recovery',
    description: 'Payment negotiation, delinquency prediction, and recovery optimization.',
    modules: [
      'Collections Agent',
      'Payment Predictor',
      'Delinquency Scorer',
      'Outreach Optimizer',
      'Dispute Analyzer'
    ],
    impact: {
      processing: '3x faster',
      accuracy: '92% prediction',
      cost: '65% reduction'
    }
  },
  {
    title: 'Trade Finance',
    description: 'Document processing, letter of credit automation, and trade compliance.',
    modules: [
      'Document Analyzer',
      'LC Issuer Agent',
      'Trade Compliance Checker',
      'Invoice Processor',
      'Settlement Monitor'
    ],
    impact: {
      processing: '90% automation',
      accuracy: '99% correctness',
      cost: '75% reduction'
    }
  },
  {
    title: 'Mortgage Services',
    description: 'Application processing, appraisal review, and underwriting automation.',
    modules: [
      'Mortgage Agent',
      'Appraisal Analyzer',
      'Underwriting Assistant',
      'Document Verifier',
      'Compliance Checker'
    ],
    impact: {
      processing: '80% faster',
      accuracy: '95% accuracy',
      cost: '72% reduction'
    }
  }
];

export default function CollectionsPage() {
  return (
    <main className="min-h-screen">
      <Header />

      {/* Hero */}
      <section className="py-20 md:py-32 border-b border-border/40">
        <div className="container px-4">
          <div className="max-w-3xl">
            <h1 className="text-4xl md:text-5xl font-bold text-foreground mb-6">
              Collections: <GradientText>Industry Solutions</GradientText>
            </h1>
            <p className="text-lg text-muted-foreground mb-8">
              Pre-configured collections of modules, agents, and workflows tailored to specific banking segments. Deploy proven solutions in days.
            </p>
          </div>
        </div>
      </section>

      {/* Collections Grid */}
      <section className="py-20 md:py-32 border-b border-border/40">
        <div className="container px-4">
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {COLLECTIONS.map((collection, index) => (
              <GlowCard key={index} delay={index * 0.05}>
                <h3 className="text-lg font-semibold text-foreground mb-2">
                  {collection.title}
                </h3>
                <p className="text-sm text-muted-foreground mb-6">
                  {collection.description}
                </p>

                <div className="space-y-4 pt-6 border-t border-border/40">
                  <div>
                    <p className="text-xs font-semibold text-accent uppercase mb-2">
                      Included Modules
                    </p>
                    <div className="space-y-1">
                      {collection.modules.map((module, modIndex) => (
                        <div key={modIndex} className="flex items-center gap-2">
                          <CheckCircle2 className="w-3 h-3 text-accent flex-shrink-0" />
                          <span className="text-xs text-muted-foreground">{module}</span>
                        </div>
                      ))}
                    </div>
                  </div>

                  <div>
                    <p className="text-xs font-semibold text-accent uppercase mb-2">
                      Typical Impact
                    </p>
                    <div className="space-y-1 text-xs text-muted-foreground">
                      <div className="flex items-center gap-2">
                        <TrendingUp className="w-3 h-3 text-accent" />
                        Processing: {collection.impact.processing}
                      </div>
                      <div className="flex items-center gap-2">
                        <TrendingUp className="w-3 h-3 text-accent" />
                        Accuracy: {collection.impact.accuracy}
                      </div>
                      <div className="flex items-center gap-2">
                        <TrendingUp className="w-3 h-3 text-accent" />
                        Cost: {collection.impact.cost}
                      </div>
                    </div>
                  </div>
                </div>
              </GlowCard>
            ))}
          </div>
        </div>
      </section>

      {/* How Collections Work */}
      <section className="py-20 md:py-32 border-b border-border/40 bg-secondary/30">
        <div className="container px-4">
          <h2 className="text-3xl font-bold text-foreground mb-12">
            How Collections Work
          </h2>

          <div className="max-w-3xl space-y-6">
            {[
              {
                step: 1,
                title: 'Choose Your Collection',
                description: 'Select the collection that matches your business segment: Commercial Banking, Retail, Risk & Compliance, etc.'
              },
              {
                step: 2,
                title: 'Configure for Your Bank',
                description: 'Customize the included modules with your policies, workflows, and integration requirements.'
              },
              {
                step: 3,
                title: 'Deploy to Production',
                description: 'One-click deployment with built-in monitoring, compliance tracking, and observability.'
              },
              {
                step: 4,
                title: 'Measure Impact',
                description: 'Track KPIs: processing time, accuracy, cost reduction, compliance coverage, and user adoption.'
              }
            ].map((item) => (
              <GlowCard key={item.step}>
                <div className="flex gap-6">
                  <div className="flex-shrink-0">
                    <div className="flex h-12 w-12 items-center justify-center rounded-full bg-accent/20 text-accent font-bold">
                      {item.step}
                    </div>
                  </div>
                  <div>
                    <h3 className="text-lg font-semibold text-foreground mb-2">
                      {item.title}
                    </h3>
                    <p className="text-muted-foreground">
                      {item.description}
                    </p>
                  </div>
                </div>
              </GlowCard>
            ))}
          </div>
        </div>
      </section>

      {/* Customization */}
      <section className="py-20 md:py-32 border-b border-border/40">
        <div className="container px-4">
          <h2 className="text-3xl font-bold text-foreground mb-12">
            Fully Customizable
          </h2>

          <div className="grid md:grid-cols-3 gap-6">
            {[
              {
                title: 'Mix & Match Modules',
                description: 'Use all modules from a collection or pick and choose to build your own.'
              },
              {
                title: 'Custom Workflows',
                description: 'Define your own approval chains, escalation logic, and decision rules.'
              },
              {
                title: 'Data Integrations',
                description: 'Connect to your core banking, CRM, and data warehouse systems.'
              },
              {
                title: 'Policy Configuration',
                description: 'Encode your lending policies, risk parameters, and compliance rules.'
              },
              {
                title: 'Model Fine-Tuning',
                description: 'Adapt domain models to your specific data and use cases.'
              },
              {
                title: 'Extended Deployment',
                description: 'Multi-region, high-availability, or edge deployment options.'
              }
            ].map((feature, index) => (
              <GlowCard key={index} delay={index * 0.05}>
                <h3 className="text-lg font-semibold text-foreground mb-2">
                  {feature.title}
                </h3>
                <p className="text-sm text-muted-foreground">
                  {feature.description}
                </p>
              </GlowCard>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-20 md:py-32 border-t border-border/40 bg-primary text-primary-foreground">
        <div className="container px-4 text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-6">
            Find your perfect collection
          </h2>
          <p className="text-lg mb-8 opacity-90 max-w-2xl mx-auto">
            Pre-built, proven, and production-ready. Deploy in days, not months.
          </p>
          <Link href="/signup">
            <Button size="lg" className="bg-accent text-accent-foreground hover:bg-accent/90">
              Explore Collections
            </Button>
          </Link>
        </div>
      </section>

      <Footer />
    </main>
  );
}
