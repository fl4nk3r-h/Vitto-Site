import { Header } from '@/components/header';
import { Footer } from '@/components/footer';
import { GradientText } from '@/components/ui/gradient-text';
import { GlowCard } from '@/components/ui/glow-card';
import { AGENTIC_AI_AGENTS } from '@/lib/constants/modules';
import Link from 'next/link';
import { Button } from '@/components/ui/button';
import { CheckCircle2 } from 'lucide-react';

export default function AgenticAIPage() {
  return (
    <main className="min-h-screen">
      <Header />

      {/* Hero */}
      <section className="py-20 md:py-32 border-b border-border/40">
        <div className="container px-4">
          <div className="max-w-3xl">
            <h1 className="text-4xl md:text-5xl font-bold text-foreground mb-6">
              Autonomous <GradientText>AI Agents</GradientText> for Banking
            </h1>
            <p className="text-lg text-muted-foreground mb-8">
              Pre-built agents for loan processing, customer service, and fraud detection. Multi-step workflows with tool calling, decision logic, and external system integration.
            </p>
          </div>
        </div>
      </section>

      {/* Agents */}
      <section className="py-20 md:py-32 border-b border-border/40">
        <div className="container px-4">
          <div className="max-w-2xl mb-16">
            <h2 className="text-3xl font-bold text-foreground mb-4">
              Pre-Built Agents
            </h2>
            <p className="text-lg text-muted-foreground">
              Each agent is a complete autonomous system trained on BFSI workflows. Deploy independently or combine for complex orchestrations.
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {AGENTIC_AI_AGENTS.map((agent, index) => (
              <GlowCard key={index} delay={index * 0.1}>
                <h3 className="text-lg font-semibold text-foreground mb-3">
                  {agent.name}
                </h3>
                <p className="text-sm text-muted-foreground mb-6">
                  {agent.description}
                </p>
                <div className="space-y-2">
                  <p className="text-xs font-semibold text-accent uppercase">Capabilities</p>
                  {agent.capabilities.map((capability, capIndex) => (
                    <div key={capIndex} className="flex items-start gap-2">
                      <CheckCircle2 className="w-4 h-4 text-accent flex-shrink-0 mt-0.5" />
                      <span className="text-xs text-muted-foreground">{capability}</span>
                    </div>
                  ))}
                </div>
              </GlowCard>
            ))}
          </div>
        </div>
      </section>

      {/* RAG Architecture */}
      <section className="py-20 md:py-32 border-b border-border/40 bg-secondary/30">
        <div className="container px-4">
          <div className="max-w-3xl mb-12">
            <h2 className="text-3xl font-bold text-foreground mb-4">
              RAG Pipeline: Grounded Answers
            </h2>
            <p className="text-lg text-muted-foreground">
              Retrieval-Augmented Generation connects your agents to company knowledge bases, policy documents, and real-time data.
            </p>
          </div>

          <div className="grid md:grid-cols-4 gap-4 mb-12">
            {[
              {
                step: '1',
                title: 'Query Received',
                description: 'Customer asks a question or agent needs context.'
              },
              {
                step: '2',
                title: 'Knowledge Search',
                description: 'RAG searches your document store and data warehouse.'
              },
              {
                step: '3',
                title: 'Augmented Generation',
                description: 'Model generates response with relevant context injected.'
              },
              {
                step: '4',
                title: 'Sourced Answer',
                description: 'Response includes citations and references to source data.'
              }
            ].map((item, index) => (
              <GlowCard key={index}>
                <div className="text-3xl font-bold text-accent mb-2">
                  {item.step}
                </div>
                <h3 className="text-sm font-semibold text-foreground mb-2">
                  {item.title}
                </h3>
                <p className="text-xs text-muted-foreground">
                  {item.description}
                </p>
              </GlowCard>
            ))}
          </div>

          <div className="border border-border/40 rounded-lg p-8 bg-background">
            <h3 className="text-lg font-semibold text-foreground mb-6 text-center">
              RAG Pipeline Diagram
            </h3>
            <div className="space-y-4">
              <div className="flex items-center justify-center gap-4 text-sm">
                <div className="bg-accent/20 text-accent rounded-lg px-4 py-2 font-semibold">
                  Query
                </div>
                <div className="text-muted-foreground">→</div>
              </div>
              <div className="flex items-center justify-center gap-4 text-sm">
                <div className="bg-secondary rounded-lg px-4 py-2 text-foreground font-semibold">
                  Vector DB Search
                </div>
                <div className="text-muted-foreground">→</div>
              </div>
              <div className="flex items-center justify-center gap-4 text-sm">
                <div className="bg-secondary rounded-lg px-4 py-2 text-foreground font-semibold">
                  Chunk Retrieval
                </div>
                <div className="text-muted-foreground">→</div>
              </div>
              <div className="flex items-center justify-center gap-4 text-sm">
                <div className="bg-secondary rounded-lg px-4 py-2 text-foreground font-semibold">
                  Context Injection
                </div>
                <div className="text-muted-foreground">→</div>
              </div>
              <div className="flex items-center justify-center gap-4 text-sm">
                <div className="bg-accent/20 text-accent rounded-lg px-4 py-2 font-semibold">
                  Grounded Response
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Agent Orchestration */}
      <section className="py-20 md:py-32 border-b border-border/40">
        <div className="container px-4">
          <h2 className="text-3xl font-bold text-foreground mb-12">
            Multi-Agent Orchestration
          </h2>

          <div className="grid md:grid-cols-2 gap-8">
            <GlowCard>
              <h3 className="text-lg font-semibold text-foreground mb-4">
                Sequential Workflows
              </h3>
              <p className="text-sm text-muted-foreground mb-4">
                Agent A processes data, Agent B makes decisions, Agent C executes actions. Perfect for loan processing workflows.
              </p>
              <div className="space-y-2 text-xs text-muted-foreground">
                <div>✓ Agent 1: Document Classification</div>
                <div>✓ Agent 2: Risk Assessment</div>
                <div>✓ Agent 3: Approval/Denial</div>
              </div>
            </GlowCard>

            <GlowCard>
              <h3 className="text-lg font-semibold text-foreground mb-4">
                Parallel Processing
              </h3>
              <p className="text-sm text-muted-foreground mb-4">
                Multiple agents work simultaneously on different aspects. Perfect for customer service queries.
              </p>
              <div className="space-y-2 text-xs text-muted-foreground">
                <div>✓ Agent 1: Account Lookup (parallel)</div>
                <div>✓ Agent 2: Transaction Search (parallel)</div>
                <div>✓ Agent 3: Policy Check (parallel)</div>
              </div>
            </GlowCard>
          </div>
        </div>
      </section>

      {/* Use Cases */}
      <section className="py-20 md:py-32 border-t border-border/40 bg-secondary/30">
        <div className="container px-4">
          <h2 className="text-3xl font-bold text-foreground mb-12">
            Banking Use Cases
          </h2>

          <div className="grid md:grid-cols-2 gap-6">
            {[
              {
                title: 'Loan Processing',
                details: [
                  'Automated application review',
                  'Document verification',
                  'Risk scoring',
                  'Approval workflow'
                ]
              },
              {
                title: 'Customer Service',
                details: [
                  'Multi-channel support (Chat, Phone)',
                  'Account lookups & transactions',
                  'Issue resolution & escalation',
                  'Product recommendations'
                ]
              },
              {
                title: 'Fraud Detection',
                details: [
                  'Real-time transaction monitoring',
                  'Pattern recognition',
                  'Alert generation',
                  'Investigation support'
                ]
              },
              {
                title: 'Collections',
                details: [
                  'Payment negotiation',
                  'Compliance scoring',
                  'Outreach optimization',
                  'Recovery prediction'
                ]
              }
            ].map((useCase, index) => (
              <GlowCard key={index} delay={index * 0.1}>
                <h3 className="text-lg font-semibold text-foreground mb-4">
                  {useCase.title}
                </h3>
                <ul className="space-y-2">
                  {useCase.details.map((detail, detailIndex) => (
                    <li key={detailIndex} className="flex items-center gap-2 text-sm text-muted-foreground">
                      <CheckCircle2 className="w-4 h-4 text-accent flex-shrink-0" />
                      {detail}
                    </li>
                  ))}
                </ul>
              </GlowCard>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-20 md:py-32 border-t border-border/40 bg-primary text-primary-foreground">
        <div className="container px-4 text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-6">
            Deploy intelligent agents at scale
          </h2>
          <p className="text-lg mb-8 opacity-90 max-w-2xl mx-auto">
            Pre-built agents for banking. Customize with RAG pipelines and external integrations. Go live in weeks.
          </p>
          <Link href="/signup">
            <Button size="lg" className="bg-accent text-accent-foreground hover:bg-accent/90">
              Start Building
            </Button>
          </Link>
        </div>
      </section>

      <Footer />
    </main>
  );
}
