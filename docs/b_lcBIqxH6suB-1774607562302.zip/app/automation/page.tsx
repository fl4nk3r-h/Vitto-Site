import { Header } from '@/components/header';
import { Footer } from '@/components/footer';
import { GradientText } from '@/components/ui/gradient-text';
import { GlowCard } from '@/components/ui/glow-card';
import { OPERATIONAL_MODULES } from '@/lib/constants/modules';
import Link from 'next/link';
import { Button } from '@/components/ui/button';
import { Layers, Database, Zap, Shield, Eye } from 'lucide-react';

const layerIcons = {
  'Data Foundation': Database,
  'Model Layer': Zap,
  'Integration Layer': Layers,
  'Compliance & Security': Shield,
  'Observability': Eye
};

export default function AutomationPage() {
  return (
    <main className="min-h-screen">
      <Header />

      {/* Hero */}
      <section className="py-20 md:py-32 border-b border-border/40">
        <div className="container px-4">
          <div className="max-w-3xl">
            <h1 className="text-4xl md:text-5xl font-bold text-foreground mb-6">
              29+ <GradientText>Operational Modules</GradientText> for Full-Stack Banking Automation
            </h1>
            <p className="text-lg text-muted-foreground mb-8">
              Five intelligent layers: Data Foundation, Model Management, Integration, Compliance, and Observability. Build your complete AI infrastructure with composable, production-ready modules.
            </p>
          </div>
        </div>
      </section>

      {/* Operational Layers */}
      {OPERATIONAL_MODULES.map((layer, layerIndex) => {
        const IconComponent = layerIcons[layer.layer as keyof typeof layerIcons] || Zap;

        return (
          <section key={layer.layer} className={layerIndex % 2 === 1 ? 'bg-secondary/30' : ''}>
            <div className="py-20 md:py-32 border-b border-border/40">
              <div className="container px-4">
                <div className="flex items-center gap-3 mb-12">
                  <IconComponent className="w-8 h-8 text-accent" />
                  <h2 className="text-3xl font-bold text-foreground">
                    {layer.layer}
                  </h2>
                </div>

                <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {layer.modules.map((module, index) => (
                    <GlowCard key={index} delay={index * 0.05}>
                      <h3 className="text-lg font-semibold text-foreground mb-2">
                        {module.name}
                      </h3>
                      <p className="text-sm text-muted-foreground">
                        {module.description}
                      </p>
                    </GlowCard>
                  ))}
                </div>
              </div>
            </div>
          </section>
        );
      })}

      {/* Architecture Overview */}
      <section className="py-20 md:py-32">
        <div className="container px-4">
          <h2 className="text-3xl font-bold text-foreground mb-12 text-center">
            How the Layers Work Together
          </h2>

          <div className="max-w-3xl mx-auto space-y-6">
            {[
              {
                title: 'Data flows from your systems into the Data Foundation',
                description: 'Ingestion, validation, governance, and secure storage powered by 5 core modules.'
              },
              {
                title: 'Models train and serve predictions via the Model Layer',
                description: 'Registry, training pipelines, evaluation, inference, and monitoring—all automated.'
              },
              {
                title: 'Integrations connect everything via the Integration Layer',
                description: 'APIs, webhooks, caching, load balancing, and failover mechanisms ensure reliability.'
              },
              {
                title: 'Compliance & Security enforces BFSI standards automatically',
                description: 'Audit logging, access controls, data residency, encryption, and regulatory reporting.'
              },
              {
                title: 'Observability gives you real-time visibility into everything',
                description: 'Distributed tracing, metrics, logs, alerts, and dashboards for complete transparency.'
              }
            ].map((step, index) => (
              <GlowCard key={index}>
                <div className="flex gap-4">
                  <div className="flex-shrink-0 w-8 h-8 rounded-full bg-accent/20 flex items-center justify-center text-accent font-semibold">
                    {index + 1}
                  </div>
                  <div>
                    <h3 className="text-lg font-semibold text-foreground mb-2">
                      {step.title}
                    </h3>
                    <p className="text-muted-foreground text-sm">
                      {step.description}
                    </p>
                  </div>
                </div>
              </GlowCard>
            ))}
          </div>
        </div>
      </section>

      {/* Module Composition Example */}
      <section className="py-20 md:py-32 border-t border-border/40 bg-secondary/30">
        <div className="container px-4">
          <h2 className="text-3xl font-bold text-foreground mb-12">
            Real-World Example: Loan Processing Automation
          </h2>

          <div className="grid md:grid-cols-2 gap-8">
            <GlowCard>
              <h3 className="text-lg font-semibold text-foreground mb-4">
                Modules Used
              </h3>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li className="flex items-center gap-2">
                  <span className="w-2 h-2 bg-accent rounded-full" />
                  Data Ingestion (upload application documents)
                </li>
                <li className="flex items-center gap-2">
                  <span className="w-2 h-2 bg-accent rounded-full" />
                  Model Inference (extract info & assess risk)
                </li>
                <li className="flex items-center gap-2">
                  <span className="w-2 h-2 bg-accent rounded-full" />
                  API Gateway (expose to core banking)
                </li>
                <li className="flex items-center gap-2">
                  <span className="w-2 h-2 bg-accent rounded-full" />
                  Audit Logging (compliance & regulatory)
                </li>
                <li className="flex items-center gap-2">
                  <span className="w-2 h-2 bg-accent rounded-full" />
                  Monitoring (detect failures early)
                </li>
              </ul>
            </GlowCard>

            <GlowCard>
              <h3 className="text-lg font-semibold text-foreground mb-4">
                Results
              </h3>
              <div className="space-y-4 text-sm">
                <div>
                  <p className="text-accent font-semibold text-lg">92%</p>
                  <p className="text-muted-foreground">Faster than manual review</p>
                </div>
                <div>
                  <p className="text-accent font-semibold text-lg">99.9%</p>
                  <p className="text-muted-foreground">Accuracy in document extraction</p>
                </div>
                <div>
                  <p className="text-accent font-semibold text-lg">100%</p>
                  <p className="text-muted-foreground">Audit trail coverage</p>
                </div>
              </div>
            </GlowCard>
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-20 md:py-32 border-t border-border/40 bg-primary text-primary-foreground">
        <div className="container px-4 text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-6">
            Build your automation layer today
          </h2>
          <p className="text-lg mb-8 opacity-90 max-w-2xl mx-auto">
            Combine modules to solve your specific banking AI challenges. Production-ready in days, not months.
          </p>
          <Link href="/signup">
            <Button size="lg" className="bg-accent text-accent-foreground hover:bg-accent/90">
              Get Started
            </Button>
          </Link>
        </div>
      </section>

      <Footer />
    </main>
  );
}
