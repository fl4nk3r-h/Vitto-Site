'use client';

import { Header } from '@/components/header';
import { Footer } from '@/components/footer';
import { StepIndicator } from '@/components/ui/step-indicator';
import { StepEmail } from '@/components/signup/step-email';
import { StepOTP } from '@/components/signup/step-otp';
import { StepOrganization } from '@/components/signup/step-organization';
import { useState } from 'react';

import { CheckCircle2 } from 'lucide-react';
import Link from 'next/link';
import { Button } from '@/components/ui/button';
import { useOTP } from '@/lib/hooks/useOTP';

type Step = 'email' | 'otp' | 'organization' | 'success';

export default function SignUpPage() {
  const [step, setStep] = useState<Step>('email');
  const [email, setEmail] = useState('');
  const [sessionToken, setSessionToken] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const { otp, handleChange: handleOtpChange, handleKeyDown: handleOtpKeyDown } = useOTP();
  const [formData, setFormData] = useState({
    institutionName: '',
    institutionType: '',
    city: '',
    phoneNumber: '',
    loanBookSize: ''
  });

  const handleSendOTP = async () => {
    setIsLoading(true);
    setError(null);
    try {
      const response = await fetch('/api/auth/send-otp', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email })
      });

      if (!response.ok) {
        throw new Error('Failed to send OTP');
      }

      setStep('otp');
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to send OTP');
    } finally {
      setIsLoading(false);
    }
  };

  const handleResendOTP = async () => {
    setIsLoading(true);
    setError(null);
    try {
      const response = await fetch('/api/auth/send-otp', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email })
      });

      if (!response.ok) {
        throw new Error('Failed to resend OTP');
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to resend OTP');
    } finally {
      setIsLoading(false);
    }
  };

  const handleVerifyOTP = async () => {
    setIsLoading(true);
    setError(null);
    try {
      const otpString = otp.join('');
      const response = await fetch('/api/auth/verify-otp', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, otp: otpString })
      });

      if (!response.ok) {
        throw new Error('Invalid OTP');
      }

      const data = await response.json();
      setSessionToken(data.sessionToken);
      setStep('organization');
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to verify OTP');
    } finally {
      setIsLoading(false);
    }
  };

  const handleFormChange = (field: string, value: string) => {
    setFormData(prev => ({
      ...prev,
      [field]: value
    }));
  };

  const handleCreateAccount = async () => {
    if (!sessionToken) {
      setError('Session expired. Please start over.');
      setStep('email');
      return;
    }

    setIsLoading(true);
    setError(null);
    try {
      const response = await fetch('/api/leads', {
        method: 'POST',
        headers: { 
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${sessionToken}`
        },
        body: JSON.stringify({
          email,
          institutionName: formData.institutionName,
          institutionType: formData.institutionType,
          city: formData.city,
          phoneNumber: formData.phoneNumber,
          loanBookSize: formData.loanBookSize
        })
      });

      if (!response.ok) {
        throw new Error('Failed to create account');
      }

      setStep('success');
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to create account');
    } finally {
      setIsLoading(false);
    }
  };

  const getStepNumber = () => {
    switch (step) {
      case 'email': return 1;
      case 'otp': return 2;
      case 'organization': return 3;
      case 'success': return 4;
      default: return 1;
    }
  };

  return (
    <main className="min-h-screen">
      <Header />

      <section className="py-12 md:py-20 border-b border-border/40">
        <div className="container px-4 max-w-2xl">
          {/* Step Indicator */}
          {step !== 'success' && (
            <div className="mb-12">
              <StepIndicator
                currentStep={getStepNumber()}
                totalSteps={3}
                labels={['Email', 'Verify', 'Details']}
              />
            </div>
          )}

          {/* Content */}
          {step === 'success' ? (
            <div className="fade-in-up text-center py-12">
              <div className="flex justify-center mb-6">
                <CheckCircle2 className="w-16 h-16 text-accent" />
              </div>
              <h1 className="text-3xl md:text-4xl font-bold text-foreground mb-4">
                Welcome to Vitto!
              </h1>
              <p className="text-lg text-muted-foreground mb-8">
                Your account has been created successfully. A confirmation email has been sent to <span className="font-semibold text-foreground">{email}</span>.
              </p>

              <div className="bg-secondary/30 border border-border/40 rounded-lg p-6 mb-8 text-left">
                <h3 className="font-semibold text-foreground mb-4">What&apos;s Next?</h3>
                <ul className="space-y-3 text-sm text-muted-foreground">
                  <li className="flex items-start gap-3">
                    <span className="text-accent font-bold">1</span>
                    <span>Check your email for your account confirmation</span>
                  </li>
                  <li className="flex items-start gap-3">
                    <span className="text-accent font-bold">2</span>
                    <span>Log in to the Vitto dashboard</span>
                  </li>
                  <li className="flex items-start gap-3">
                    <span className="text-accent font-bold">3</span>
                    <span>Start your free trial with access to all 6 core modules</span>
                  </li>
                </ul>
              </div>

              <Link href="/">
                <Button className="bg-accent text-accent-foreground hover:bg-accent/90">
                  Return to Home
                </Button>
              </Link>
            </div>
          ) : (
            <div>
              <h1 className="text-3xl md:text-4xl font-bold text-foreground mb-2">
                Join Vitto
              </h1>
              <p className="text-muted-foreground mb-12">
                {step === 'email' && 'Start your free trial of our AI-first banking infrastructure.'}
                {step === 'otp' && 'Verify your email with the code we sent.'}
                {step === 'organization' && 'Tell us about your institution.'}
              </p>

              {/* Step Content */}
              <div className="bg-card border border-border/40 rounded-lg p-8">
                {step === 'email' && (
                  <StepEmail
                    email={email}
                    onEmailChange={setEmail}
                    onNext={handleSendOTP}
                    isLoading={isLoading}
                    error={error}
                  />
                )}

                {step === 'otp' && (
                  <StepOTP
                    email={email}
                    otp={otp}
                    onOtpChange={handleOtpChange}
                    onOtpKeyDown={handleOtpKeyDown}
                    onVerify={handleVerifyOTP}
                    onResend={handleResendOTP}
                    isLoading={isLoading}
                    error={error}
                  />
                )}

                {step === 'organization' && (
                  <StepOrganization
                    formData={formData}
                    onChange={handleFormChange}
                    onSubmit={handleCreateAccount}
                    isLoading={isLoading}
                    error={error}
                  />
                )}
              </div>

              {/* Back Link */}
              {(step === 'otp' || step === 'organization') && (
                <button
                  onClick={() => {
                    if (step === 'otp') {
                      setStep('email');
                    } else {
                      setStep('otp');
                    }
                    setError(null);
                  }}
                  className="mt-4 text-sm text-muted-foreground hover:text-foreground transition-colors"
                >
                  ← Back
                </button>
              )}
            </div>
          )}
        </div>
      </section>

      {/* Benefits */}
      {step !== 'success' && (
        <section className="py-12 md:py-20 bg-secondary/30">
          <div className="container px-4">
            <div className="grid md:grid-cols-3 gap-8 max-w-4xl">
              {[
                {
                  title: '6 Core Modules',
                  description: 'SLM Core, RAG, Agents, Compliance, Monitoring, Integration'
                },
                {
                  title: '29+ Operational Features',
                  description: 'Data, Models, Integration, Compliance, Observability layers'
                },
                {
                  title: 'Production-Ready',
                  description: 'Deploy in hours. BFSI compliant. 99.99% uptime SLA'
                }
              ].map((benefit, index) => (
                <div key={index}>
                  <h3 className="font-semibold text-foreground mb-2">{benefit.title}</h3>
                  <p className="text-sm text-muted-foreground">{benefit.description}</p>
                </div>
              ))}
            </div>
          </div>
        </section>
      )}

      <Footer />
    </main>
  );
}
